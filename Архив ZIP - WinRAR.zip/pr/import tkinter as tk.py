import tkinter as tk
from tkinter import messagebox, simpledialog

class ConcertManager:
    def __init__(self, root):
        self.root = root
        self.root.title("Учет концертов")
        self.concerts = []

        self.listbox = tk.Listbox(root, width=50)
        self.listbox.pack(pady=10)

        btn_frame = tk.Frame(root)
        btn_frame.pack()

        tk.Button(btn_frame, text="Добавить концерт", command=self.add_concert).grid(row=0, column=0, padx=5)
        tk.Button(btn_frame, text="Удалить выбранный", command=self.delete_concert).grid(row=0, column=1, padx=5)
        tk.Button(btn_frame, text="Посмотреть детали", command=self.show_details).grid(row=0, column=2, padx=5)

    def add_concert(self):
        name = simpledialog.askstring("Название", "Введите название концерта:")
        if not name:
            return
        date = simpledialog.askstring("Дата", "Введите дату концерта (ДД.ММ.ГГГГ):")
        if not date:
            return
        place = simpledialog.askstring("Место", "Введите место проведения:")
        if not place:
            return
        self.concerts.append({'name': name, 'date': date, 'place': place})
        self.listbox.insert(tk.END, f"{name} | {date} | {place}")

    def delete_concert(self):
        idx = self.listbox.curselection()
        if not idx:
            return
        self.listbox.delete(idx)
        del self.concerts[idx[0]]

    def show_details(self):
        idx = self.listbox.curselection()
        if not idx:
            return
        concert = self.concerts[idx[0]]
        messagebox.showinfo("Детали концерта",
                            f"Название: {concert['name']}\nДата: {concert['date']}\nМесто: {concert['place']}")

if __name__ == "__main__":
    root = tk.Tk()
    app = ConcertManager(root)
    root.mainloop()