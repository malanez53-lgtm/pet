import mysql.connector
from mysql.connector import Error
from models import Concert

class Database:
    def __init__(self, host, user, password, database):
        self.connection = None
        try:
            self.connection = mysql.connector.connect(
                host=host,
                user=user,
                password=password,
                database=database
            )
            if self.connection.is_connected():
                print("Successfully connected to the database")
        except Error as e:
            print(f"Error: '{e}'")

    def get_all_concerts(self):
        concerts = []
        query = "SELECT id, name, date, place FROM concerts"
        cursor = self.connection.cursor()
        try:
            cursor.execute(query)
            for row in cursor.fetchall():
                concert = Concert(row[1], row[2], row[3])
                concert.id = row[0]
                concerts.append(concert)
        except Error as e:
            print(f"Error: '{e}'")
        finally:
            cursor.close()
        return concerts

    def create_table(self):
        create_table_query = """
        CREATE TABLE IF NOT EXISTS concerts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            date DATE NOT NULL,
            place VARCHAR(255) NOT NULL
        );
        """
        cursor = self.connection.cursor()
        try:
            cursor.execute(create_table_query)
            print("Concerts table created successfully")
        except Error as e:
            print(f"Error: '{e}'")
        finally:
            cursor.close()

    def add_concert(self, concert):
        insert_query = """
        INSERT INTO concerts (name, date, place) VALUES (%s, %s, %s);
        """
        cursor = self.connection.cursor()
        try:
            cursor.execute(insert_query, (concert.name, concert.date, concert.place))
            self.connection.commit()
            concert.id = cursor.lastrowid
            print("Concert inserted successfully")
        except Error as e:
            print(f"Error: '{e}'")
        finally:
            cursor.close()

    def delete_concert(self, concert_id):
        delete_query = "DELETE FROM concerts WHERE id = %s;"
        cursor = self.connection.cursor()
        try:
            cursor.execute(delete_query, (concert_id,))
            self.connection.commit()
            print("Concert deleted successfully")
        except Error as e:
            print(f"Error: '{e}'")
        finally:
            cursor.close()

    def get_concerts(self):
        select_query = "SELECT * FROM concerts;"
        cursor = self.connection.cursor(dictionary=True)
        concerts = []
        try:
            cursor.execute(select_query)
            concerts = cursor.fetchall()
        except Error as e:
            print(f"Error: '{e}'")
        finally:
            cursor.close()
        return concerts

    def close_connection(self):
        if self.connection.is_connected():
            self.connection.close()
            print("Database connection closed")