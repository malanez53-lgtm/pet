# Concert Manager

This project is a concert management application built using Python's Tkinter for the GUI and MySQL for database management. It allows users to add, delete, and view concert details efficiently.

## Project Structure

```
concert-manager
├── src
│   ├── app.py          # Entry point of the application
│   ├── db.py           # Database connection and operations
│   └── models.py       # Data model for concert records
├── requirements.txt     # Project dependencies
└── README.md            # Project documentation
```

## Setup Instructions

1. **Clone the repository:**
   ```
   git clone <repository-url>
   cd concert-manager
   ```

2. **Install dependencies:**
   Make sure you have Python installed. Then, install the required packages using pip:
   ```
   pip install -r requirements.txt
   ```

3. **Set up MySQL Database:**
   - Ensure you have MySQL installed and running.
   - Create a database for the concert manager application.
   - Update the database connection details in `src/db.py` as needed.

## Usage Guidelines

- Run the application by executing the following command:
  ```
  python src/app.py
  ```
- Use the GUI to add new concerts, delete existing ones, and view details of selected concerts.

## Database Schema

The application uses a MySQL database to store concert records. The schema includes the following fields:

- **id**: INT, Primary Key, Auto Increment
- **name**: VARCHAR(255), Name of the concert
- **date**: DATE, Date of the concert
- **place**: VARCHAR(255), Venue of the concert

## Contributing

Feel free to submit issues or pull requests for improvements or bug fixes.