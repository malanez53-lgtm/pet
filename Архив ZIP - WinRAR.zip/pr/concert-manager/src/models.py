class Concert:
    def __init__(self, name, date, place):
        self.name = name
        self.date = date
        self.place = place

    def save(self, cursor):
        cursor.execute("INSERT INTO concerts (name, date, place) VALUES (%s, %s, %s)", 
                       (self.name, self.date, self.place))

    @staticmethod
    def delete(cursor, concert_id):
        cursor.execute("DELETE FROM concerts WHERE id = %s", (concert_id,))

    @staticmethod
    def get_all(cursor):
        cursor.execute("SELECT * FROM concerts")
        return cursor.fetchall()

    @staticmethod
    def get_by_id(cursor, concert_id):
        cursor.execute("SELECT * FROM concerts WHERE id = %s", (concert_id,))
        return cursor.fetchone()