import tkinter as tk
from tkinter import messagebox, simpledialog
from db import Database
from models import Concert

class ConcertManager:
    def __init__(self, root):
        self.root = root
        self.root.title("Учет концертов")
        self.db = Database(
            host="localhost",
            user="wimoy",
            password="1234",
            database="concert_db"
        )
        self.db.create_table()
        self.concerts = self.db.get_all_concerts()
        self.listbox = tk.Listbox(root, width=50)
        self.listbox.pack(pady=10)
        self.populate_listbox()

        btn_frame = tk.Frame(root)
        btn_frame.pack()

        tk.Button(btn_frame, text="Добавить концерт", command=self.add_concert).grid(row=0, column=0, padx=5)
        tk.Button(btn_frame, text="Удалить выбранный", command=self.delete_concert).grid(row=0, column=1, padx=5)
        tk.Button(btn_frame, text="Посмотреть детали", command=self.show_details).grid(row=0, column=2, padx=5)

    def populate_listbox(self):
        self.listbox.delete(0, tk.END)
        for concert in self.concerts:
            self.listbox.insert(tk.END, f"{concert.name} | {concert.date} | {concert.place}")

    def add_concert(self):
        name = simpledialog.askstring("Название", "Введите название концерта:")
        if not name:
            return
        date = simpledialog.askstring("Дата", "Введите дату концерта (ГГГГ.ММ.ДД):")
        if not date:
            return
        place = simpledialog.askstring("Место", "Введите место проведения:")
        if not place:
            return
        concert = Concert(name, date, place)
        self.db.add_concert(concert)
        # После добавления — обновляем список из базы, чтобы у концертов был id
        self.concerts = self.db.get_all_concerts()
        self.populate_listbox() 

    def delete_concert(self):
        idx = self.listbox.curselection()
        if not idx:
            return
        concert = self.concerts[idx[0]]
        self.db.delete_concert(concert.id)
        del self.concerts[idx[0]]
        self.populate_listbox()

    def show_details(self):
        idx = self.listbox.curselection()
        if not idx:
            return
        concert = self.concerts[idx[0]]
        messagebox.showinfo("Детали концерта",
                            f"Название: {concert.name}\nДата: {concert.date}\nМесто: {concert.place}")

if __name__ == "__main__":
    root = tk.Tk()
    app = ConcertManager(root)
    root.mainloop()